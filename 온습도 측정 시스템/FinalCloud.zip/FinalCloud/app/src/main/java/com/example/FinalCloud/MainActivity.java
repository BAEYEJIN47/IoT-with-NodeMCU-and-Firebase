package com.example.FinalCloud;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {
    private WebView WebView; //WebView 선언
    private WebSettings WebSettings; //WebView setting

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        WebView = (WebView) findViewById(R.id.webview);

        WebView.setWebViewClient(new WebViewClient()); //webView에 Client를 연결
        WebSettings = WebView.getSettings(); //웹 setting 객체 지정
        WebSettings.setJavaScriptEnabled(true); //javascript를 실행할 수 있도록 설정

        WebView.loadUrl("file:///android_asset/index.html"); //실행시킬 URI
    }

}