package com.example.firebase_led;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    Button btnON, btnOFF;
    TextView textView, textView2;
    ImageView image;

    FirebaseDatabase database = FirebaseDatabase.getInstance(); //DB 초기화
    DatabaseReference myRef = database.getReference("LED_STATUS"); //LED_STATUS 생성

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.InitializeView();
        this.SetListener();
    }

    public void InitializeView() {

        btnON = (Button)findViewById(R.id.btnON);
        btnOFF = (Button)findViewById(R.id.btnOFF);
        textView = (TextView) findViewById(R.id.textView);
        textView2 = (TextView) findViewById(R.id.textview2);
        image = (ImageView) findViewById(R.id.image);
        setTitle("LED Remote Control");
        textView.setText(myRef.getKey()); //DatabaseReference myRef에서 값을 textView에 set
    }

    public void SetListener() {
        myRef.addValueEventListener(new ValueEventListener() { //addValueEventListener는 데이터가 추가되었을 때 DB에서 지정한 child 객체 가져옴
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String ledState = (String) dataSnapshot.getValue(); //스냅샷된 값을 가져와 ledState에 저장

                textView.setText("LED is " + ledState); //ledState 값을 textview에 set해서 나타냄

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        btnON.setOnClickListener(new View.OnClickListener() { //ON버튼을 클릭했을 때
            @Override
            public void onClick(View v) {
                textView.setTextColor(Color.RED); //textView의 text를 빨간색으로 set
                myRef.setValue("ON"); //DB의 값을 ON으로 설정
            }
        });

        btnOFF.setOnClickListener(new View.OnClickListener() { //OFF버튼을 클릭했을 때
            @Override
            public void onClick(View v) {
                textView.setTextColor(Color.BLACK);//textView의 text를 검정색으로 set
                myRef.setValue("OFF"); //DB의 값을 OFF로 설정
            }
        });
    }
}
